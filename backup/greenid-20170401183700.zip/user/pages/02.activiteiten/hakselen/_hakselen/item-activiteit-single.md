---
title: Hakselen
caption: 'Foto 1&#58; Met de kniklader wordt de hakselaar van takkenhoop naar takkenhoop gereden. Dit bespaart ons heel wat stappen en tijd!<br> Foto 2&#58; Als het even kan blazen we de houtsnippers rechtstreeks in de container van de vrachtwagen.'
---
Takken met een doorsnede tot 20 à 25 cm kunnen vlot **versnipperd** worden.
We nemen, indien de klant het wenst, alle **houtafval** mee. Onze hakselaar versnippert het hout in kleine gelijkmatige stukjes. De houtsnippers kunnen daardoor ook tussen de beplanting gelegd worden om o.a. onkruid tegen te gaan en het uitdrogen van de bodem te voorkomen. Als de houtsnippers na verloop van tijd verteerd zijn, dienen die nog als **extra voeding** voor de beplanting.

Wij hebben meestal thuis nog houtsnippers voorradig. Geef ons een seintje en dan brengen wij er nog wat extra voor u mee.
