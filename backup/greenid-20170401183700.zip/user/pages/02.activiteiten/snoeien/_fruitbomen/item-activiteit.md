---
title: Fruitbomen snoeien
caption: Voor en na
chapter: chap4
item: item4
---
De snoei van de **fruitbomen** gebeurt naar van de wensen van de klant:
* in functie van het **fruit**,
* om de **levensduur** van (oude) fruitbomen te verlengen (verjongen),
* voor het **decoratieve aspect** van de boom (vorm, structuur, bloei, herfstkleur)
* of een combinatie van voorgaande doelstellingen

Het snoeien van fruitbomen kan niet vergeleken worden met het snoeien van sierbomen of -struiken. Hiervoor is een totaal andere visie nodig. Fruitbomen worden het best jaarlijks (bij sterk groeiende bomen) tot 3-jaarlijks gesnoeid. Dan heb je het beste resultaat.

Werd er al jaren niets meer aan de fruitbomen gedaan, dan kunnen we die toch nog in een redelijke tot goede conditie krijgen. Maar daarvoor vraag je best eerst ons advies.
