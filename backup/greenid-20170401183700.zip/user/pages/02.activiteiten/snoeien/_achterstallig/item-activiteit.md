---
title: Achterstallige snoei
caption: Voor en na
chapter: chap3
item: item3
---
Ook bij **achterstallige snoei** wordt zoveel mogelijk rekening gehouden met de natuurlijke habitus van de bomen. Rekening houdende met de standplaats, worden de bomen zo zorgvuldig mogelijk gesnoeid. Een goede plantenkennis is hier van groot belang! Niet iedere boom kan zomaar het hele jaar rond gesnoeid worden. De boom in het juiste seizoen snoeien, kan het verschil maken tussen het behouden van een mooie boom, of het moeten vellen van een aangetaste, gevaarlijke en/of afgestorven boom.
