---
title: Jeugd- en begeleidingssnoei
caption: jeugdsnoei
chapter: chap1
item: item1
---
Als de (aangeplante) bomen in een **jonge fase** gesnoeid worden, zullen die beter uitgroeien en grote problemen (en dus ook grotere kosten) vermeden worden. Door jonge boompjes een goede start te geven, heb je heel wat minder kans op o.a. wrijvende takken, dubbele toppen, plakoksels en dat soort dingen. De snoeiwonden zijn ook kleiner en vergroeien dus sneller, wat bacteriën en schimmels minder kans geven om de bomen aan te tasten. Aan een jonge boom is uiteraard ook heel wat minder werk…
