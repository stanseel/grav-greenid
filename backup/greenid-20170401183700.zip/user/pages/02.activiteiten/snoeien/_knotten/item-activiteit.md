---
title: Knotten / kandelaberen
caption: 'Foto&#39;s links&#58; Deze boom wordt al jaren geknot om de kroon compact te houden in de beperkte ruimte waar hij groeit. De knotwilgen worden terug op hun oude knot gezet.<br> Foto&#39;s rechts&#58; Een boom kan tegen een muur geleid worden of als groen scherm. De leilinden rond de kerk te Westkapelle waren aan een opknapbeurt toe. Ze werden terug geknot op de oude knot en er werden nieuwe scheuten geleid om het geheel weer dicht te laten groeien.'
chapter: chap5
item: item5
---
Als de bomen er zich toe lenen, kunnen ze **geknot/gekandelaberd** worden. Dit geldt niet enkel voor knotwilgen. **Platanen** en **lindes** verdragen het goed om gekandelaberd te worden, als je er in een vroeg stadium mee start. Knotten of kandelaberen van oudere bomen is helemaal uit den boze! Door de grote snoeiwonden krijgen schimmels en bacteriën er vrij spel wat tot gevaarlijke situaties leidt.
