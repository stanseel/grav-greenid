---
title: 'Uitlichten / onderhoudssnoei / zomersnoei'
caption: 'Foto&#39;s 1&#58; de takken van dit boompje duwden tegen de garage <br> Foto&#39;s 2&#58; door stamschade had deze boom al veel afgestorven takken. Al het dode hout werd verwijderd.'
---

Bij het **uitlichten** van een boom, komt heel wat meer licht door het bladerdek. Het is vaak helemaal niet nodig om een boom te vellen of ‘in te korten’ om meer zonlicht te hebben. Bij een drastische snoei krijg je daarbovenop een extra groeischeut, waardoor er nog veel meer zonlicht ontnomen wordt. En bij een te drastische snoei, is de kans groot dat de boom na een korte tijd helemaal afsterft.

Het uitlichten, de onderhoudssnoei of de zomersnoei voorkomt in grote mate **takbreuk** en **uitval** van dood hout bij bijvoorbeeld storm. Ook kunnen van dichtbij aankomende problemen (ziekte, aantastingen,…) opgemerkt worden. Bij tijdig ingrijpen wordt vaak (grotere) schade vermeden. Als er gesnoeid wordt, wordt de natuurlijke **habitus** van de boom behouden, want zo groeit een boom het best. Een onderhoudssnoei resulteert in een **vitale**, **gezonde boom** waar je nog jaren plezier aan kan hebben!
