---
title: Uitfrezen
template: activiteiten
content:
    items: @self.modular
    order:
        by: default
        custom:
            - _uitfrezen
    pagination: false
---
