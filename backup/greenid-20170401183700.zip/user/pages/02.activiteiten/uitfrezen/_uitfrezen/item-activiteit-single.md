---
title: Uitfrezen
caption: De wortels worden uitgefreesd en verwijderd. Daarna kan de put gevuld worden met grond, zodat er bijvoorbeeld opnieuw gras kan gezaaid worden.
---
De wortels kunnen uitgefreesd worden om bijvoorbeeld na het verwijderen van de boom/bomen een nieuwe beplanting te voorzien. Onze freesmachine kan door de meeste tuinhekkens en –poortjes. Hij is ook heel wendbaar en kan daardoor ook op moeilijk bereikbare plaatsen werken. Door de goede gewichtsverdeling van de freesmachine, brengt deze geen structuurschade aan de bodem toe en is er geen spoorvorming in het gazon.
