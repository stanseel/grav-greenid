---
title: Geheel vellen
caption: 'Foto&#39;s links&#58; Als er plaats genoeg is om een kraan te gebruiken, worden de bomen af gezaagd en neergelegd. Klaar om te verzagen.<br> Foto&#39;s rechts&#58; Als er weinig plaats is in de tuin, liften we de bomen/takken over gebouwen en constructies om zo snel en efficiënt de takken en de stam te verzagen en af te voeren.'
---
Indien de bomen kunnen vallen, worden ze **in hun geheel geveld**. Overdreven veel plaats is daarvoor niet nodig, als je weet wat je doet. De boom met al zijn facetten wordt goed onder de loep genomen: soort boom, zware takken, torsie, aantastingen die de breuksterkte kunnen beïnvloeden, de lengte wordt bepaald, …
Al dat soort zaken wordt goed bekeken om de juiste **valkerf** te maken, zodat de boom precies valt waar ze komen moet. Niet te veel naar links of naar rechts en niet te ver vooruit, zodat de klant met een gerust hart zijn woning, tuinhuis, omheining, andere bomen en beplanting, … aan ons kan toevertrouwen.
