---
title: Ontmantelen
caption: 'Foto&#39;s links&#58; Deze dode beuk stond tegen een muur en naast een poolhouse.<br> Foto&#39;s rechts&#58; De stam wordt tak per tak ontmanteld en de stukken worden opgevangen met touwen. Ofwel worden de takken gelift en op de grond verzaagd en verhakseld.'
---
Indien de bomen niet in hun geheel kunnen vallen, worden ze **ontmanteld en stuk voor stuk naar beneden gehaald**. Dit gebeurt heel vaak nabij woningen, afsluitingen, tuinhuizen, terrassen, zwembaden, … Er wordt steeds goed op toegezien dat er **geen schade** wordt aangericht aan bestaande bouwwerken en onderbeplanting! Kan of mag er niets vallen, dan worden de takken en de stam opgevangen en op de grond gelegd, desnoods een heel eind weg van de boom. Met behulp van touwen kunnen we de takken en stukken stam deponeren waar wij willen, als het even kan zelfs rechtstreeks in de container van de vrachtwagen…
