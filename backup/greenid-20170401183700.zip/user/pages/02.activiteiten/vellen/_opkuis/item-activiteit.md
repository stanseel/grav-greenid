---
title: Opkuis van het terrein
caption: Met onze kniklader verzamelen we snel grote hoeveelheden takken voor de hakselaar. Dit bespaart ons heel wat stappen!
---
Na de vel- en/of snoeiwerken **ruimen wij het terrein netjes op**, zodat u daar zelf geen tijd meer aan hoeft te spenderen. We hebben het nodige materiaal om snel en efficiënt te werk te gaan, zowel voor de grove opkuis als voor het fijne werk.
