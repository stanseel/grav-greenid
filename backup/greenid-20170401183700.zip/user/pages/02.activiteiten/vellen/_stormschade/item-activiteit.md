---
title: (Storm)schade opruimen
caption: We kregen een telefoontje voor een omgewaaide boom... op het dak! De boom werd van het dak gelift en naast de woning gelegd. Daarna werd de dakgoot weer vrij gemaakt van twijgen en blaadjes die er in terecht gekomen waren.
singleimage: true
---
**Stormschade** (o.a. afgebroken of uitgescheurde takken, omgewaaide bomen) wordt zorgvuldig verwijderd. Wij zijn met voldoende materiaal uitgerust om bomen – indien nodig – te liften en te verwijderen. Op die manier kan verdere schade vaak vermeden worden.

**Schade** (door o.a. bouwwerken) wordt achterhaald en de mogelijke oplossingen worden aan de klant voorgelegd en bij goedkeuring uitgevoerd.
