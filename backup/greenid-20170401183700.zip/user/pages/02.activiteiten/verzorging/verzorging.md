---
title: Boomverzorging
template: activiteiten
content:
    items: @self.modular
    order:
        by: default
        custom:
            - _bestrijding
            - _omwikkelen
            - _wondverzorging
            - _verankering
    pagination: false
---
