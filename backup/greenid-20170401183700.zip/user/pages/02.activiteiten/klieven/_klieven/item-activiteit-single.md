---
title: Klieven
caption: De stam werd verzaagd tot stukken van 40cm. Hier worden de stukken gekliefd tot kant-en-klaar brandhout.
---
De stammen en de grotere takken kunnen verzaagd en gekliefd worden. Onze kliefmachine is zo ontworpen dat we ook door de standaard deuren en tuinhekkens in de tuin geraken, zonder aan kracht te moeten inboeten. Het hout wordt op maat verzaagd, en varieert dus naargelang de wensen van de klant.

Vraag ons naar de prijsvoorwaarden als we langs komen.
