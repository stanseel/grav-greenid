---
title: 'Specialist in boomverzorging sinds 2001'
---

Welkom bij **GreenID**, specialist in de boomverzorging sinds 2001. Zaakvoerder **Ides De Vlamynck**, **certified treeworker (UK)** en **European TreeWorker**, is uw centrale aanspreekpunt. Wij staan garant voor kennis, kwaliteit en duurzaamheid. Met andere woorden “boomverzorging met verstand van zaken”!