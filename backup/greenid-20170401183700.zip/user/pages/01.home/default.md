---
title: 'Specialist boomverzorging sinds 2001'
---

Zaakvoerder Ides De Vlamynck, **certified treeworker (UK)** en **European TreeWorker**, is uw centrale aanspreekpunt. Green Id staat garant voor professionalisme, kwaliteit en duurzaamheid. Met andere woorden “boomverzorging met kennis van zaken”.